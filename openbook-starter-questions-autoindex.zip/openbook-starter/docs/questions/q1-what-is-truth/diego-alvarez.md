---
title: "What is truth?"
author: "Diego Alvarez"
country: "Argentina"
religion: "None"
language: "Spanish"
translation: "English"
summary: "Truth is the silence that remains when every excuse has been spoken."
---

# What is truth?

> *This chapter is part of the global question series. Every voice is welcome.*

## Option A — Free Essay  

Truth is a river; it bends, disappears underground, then returns.  
I bow to the moments when life proves me wrong.  

## Optional Add-ons  
- **One-sentence wisdom:** “Truth is the silence that remains when every excuse has been spoken.”
